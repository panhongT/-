#include <stdio.h>
#include <stdlib.h>
#include"size.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
		StackNode *s=(StackNode*)malloc(sizeof(StackNode));;
	LinkStack *S=(LinkStack*)malloc(sizeof(LinkStack));;
	initLStack(S);//��ʼ��һ����ջ
	char ch;
	int c[MAXSIZE];
	char *datas;
	printf("������һ������ʽ������#��Ϊ����\n");
	char a[MAXSIZE];
	char b[MAXSIZES];
	gets(a);
	int i=0;
	int j=0;
	while(a[i]!='#'){	
	if(a[i]>='0'&&a[i]<='9'){
		b[j]=a[i];
		i++;
		j++;
		if(a[i]<'0'||a[i]>'9'){
			
			b[j]=' ';
			j++;
		}
		continue; 
	}
	while(!(isEmptyLStack(S))&&judge(0,a[i])<judge(1,S->top ->ch )) {
		b[j++]=popLStack(S,datas);
		
	}
	if(isEmptyLStack(S)){
	 pushLStack(S,a[i]);
	i++;
	continue;
    }else if(judge(0,a[i])>judge(1,S->top ->ch)){
    	pushLStack(S,a[i]);
	}else if(judge(0,a[i])==judge(1,S->top ->ch)){
		popLStack(S,datas);
	}
	i++;
}
while(!isEmptyLStack(S)){

	b[j++]=popLStack(S,datas);
}
b[j]='\0';
printf("��׺����ʽΪ\n");
puts(b);
/*******************************************��ʼ�ú�׺����ʽ���м���****************************************/
i=0;
Stack_Node *s1;	
Link_Stack* S1=(Link_Stack*)malloc(sizeof(Link_Stack));
init_LStack(S1); //��ʼ��һ����ջ
double *z;
double t;
while(b[i]!='\0'){
	if(b[i]>='0'&&b[i]<='9'){
    int count=0;
	double sum=0;
	int j=i;
	while(b[i]>='0'&&b[i]<='9'){
	count++;
	i++;
	}
	int mask=1;
	while(count>1){
		mask*=10;
		count--;
	}
	for(;j<i;j++){
		
		sum+=(b[j]-48)*mask;
		mask/=10;
	}
	t=sum;
	z=&t; 
		numpushLStack(S1,t);
		continue;
}
	if(b[i]=='+'){
		double *e;
		double d=numpopLStack(S1,e);
		double c=numpopLStack(S1,e);
		double Sum=d+c;
		numpushLStack(S1,Sum);
		i++;
		continue;
	}
		else if(b[i]=='-'){
		double *e;
		double d=numpopLStack(S1,e);
		double c=numpopLStack(S1,e);
		double Sum=c-d;
		numpushLStack(S1,Sum);
		i++;
		continue;
	}
		 else if(b[i]=='*'){
		double *e;
		double d=numpopLStack(S1,e);
		double c=numpopLStack(S1,e);
		double Sum=d*c;
		numpushLStack(S1,Sum);
		i++;
		continue;
	}	
	     else if(b[i]=='/'){
		double *e;
		double d=numpopLStack(S1,e);
		double c=numpopLStack(S1,e);
		double Sum=c/d;
		numpushLStack(S1,Sum);
		i++;
		continue;
	}else {
	i++;
	}
}
 double *f;
 double g;
 g=numpopLStack(S1,f);
 printf("����ʽ�Ľ����%lf\n",g);
		getch();
	return 0;
}
